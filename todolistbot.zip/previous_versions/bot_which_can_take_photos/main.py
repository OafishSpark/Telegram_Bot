import telebot

TOKEN = ''

bot = telebot.TeleBot (TOKEN)

@bot.message_handler (commands = ['start'])
def start_handler (message):
    bot.send_message (message.from_user.id, f"Hello, {message.from_user.first_name}!")
    tdlist = open (f'todolist_{message.from_user.id}.txt', 'a')
    tdlist.close ()

@bot.message_handler (commands = ['help'])
def help_handler (message):
    bot.send_message (message.from_user.id, "I don't help pieces of meat(")

@bot.message_handler (commands = ['new_item'])
def newitem_handler (message):
    bot.send_message (message.from_user.id, 'Task has been successfully added!')
    tdlist = open (f'todolist_{message.from_user.id}.txt','a')
    mes = message.text
    mes = mes.replace('/new_item ', '')
    tdlist.write(mes + '\n')
    tdlist.close ()

@bot.message_handler (commands = ['all'])
def all_handler (message):
    tdlist = open (f'todolist_{message.from_user.id}.txt','r')
    todolist = tdlist.read ().split ('\n')
    for i in range (1, len (todolist)):
        task = todolist[i - 1].split ('----')
        mes = f'{i}' + ' ' + task[0] + '\n'
        bot.send_message (message.from_user.id, mes)
        if len (task) > 1:
            for i in range (1,len(task)):
                photo = task [i]
                bot.send_photo (message.from_user.id, photo)   
    tdlist.close ()

@bot.message_handler (commands = ['delete'])
def delete_handler (message):

    mes = message.text
    mes = mes.split ()[1]
    num = int(mes)

    bot.send_message (message.from_user.id, f'Task number {num} is deleted!')

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'r')
    todolist = tdlist.read ().split ('\n')
    todolist.pop (num - 1)

    tdlist.close ()

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'w')
    for i in range (1, len (todolist)):
        tdlist.write (todolist[i - 1] + '\n')
    tdlist.close ()

@bot.message_handler (commands = ['add_photo'])
def add_photo_handler(message):
    mes = message.text
    mes = mes.split ()[1]
    global taskforphotonum
    taskforphotonum = int (mes)

@bot.message_handler (content_types = ['photo'])
def makingphoto_handler (message):

    photo = message.photo[-1]
    file_id = photo.file_id

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'r')
    todolist = tdlist.read ().split ('\n')
    tdlist.close ()

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'w')
    for i in range (1, len (todolist)):
        if i == taskforphotonum:
            tdlist.write(todolist[i - 1] + f'----{file_id}' +'\n')
        else:   
            tdlist.write (todolist[i - 1] + '\n')
    tdlist.close ()




bot.polling ()