import telebot

TOKEN = ''

bot = telebot.TeleBot (TOKEN)

@bot.message_handler (commands = ['start'])
def start_handler (message):
    bot.send_message (message.from_user.id, f"Hello, {message.from_user.first_name}!")
    tdlist = open (f'todolist_{message.from_user.id}.txt', 'a')
    tdlist.close ()

@bot.message_handler (commands = ['help'])
def help_handler (message):
    bot.send_message (message.from_user.id, "I don't help pieces of meat(")

@bot.message_handler (commands = ['new_item'])
def newitem_handler (message):
    bot.send_message (message.from_user.id, 'Task has been successfully added!')
    tdlist = open (f'todolist_{message.from_user.id}.txt','a')
    mes = message.text
    mes = mes.replace('/new_item', '')
    tdlist.write(mes + '\n')
    tdlist.close ()

@bot.message_handler (commands = ['all'])
def all_handler (message):
    tdlist = open (f'todolist_{message.from_user.id}.txt','r')
    todolist = tdlist.read ().split ('\n')
    mes = ''
    for i in range (1, len (todolist)):
        mes += f'{i}' + todolist[i - 1] + '\n'
    bot.send_message (message.from_user.id, mes)   
    tdlist.close ()

@bot.message_handler (commands = ['delete'])
def delete_handler (message):

    mes = message.text
    mes = mes.replace ('/delete ', '')
    num = int(mes)

    bot.send_message (message.from_user.id, f'Task number {num} is deleted!')

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'r')
    todolist = tdlist.read ().split ('\n')
    todolist.pop (num - 1)

    tdlist.close ()

    tdlist = open (f'todolist_{message.from_user.id}.txt', 'w')
    for i in range (1, len (todolist)):
        tdlist.write (todolist[i - 1] + '\n')
    tdlist.close ()



bot.polling ()